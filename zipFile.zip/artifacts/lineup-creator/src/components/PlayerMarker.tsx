import { useState } from "react";
import { motion } from "framer-motion";
import { Star, UserPlus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { countries } from "@/lib/countries";
import type { Player } from "@/lib/formations";
import { JerseySVG, type JerseyStyle } from "@/components/JerseySVG";
import { NationalityPicker } from "@/components/NationalityPicker";

const LIB_KEY = "lineup-player-library";

export type LibPlayer = Omit<Player, "id" | "x" | "y">;

function loadLibrary(): LibPlayer[] {
  try { return JSON.parse(localStorage.getItem(LIB_KEY) || "[]"); } catch { return []; }
}
function saveLibrary(lib: LibPlayer[]) {
  localStorage.setItem(LIB_KEY, JSON.stringify(lib));
}

type PlayerMarkerProps = {
  player: Player;
  jerseyColor: string;
  secondaryColor: string;
  accentColor: string;
  jerseyStyle: JerseyStyle;
  showDetails: boolean;
  onUpdate: (id: string, updates: Partial<Player>) => void;
  containerRef: React.RefObject<HTMLDivElement>;
};

export function ratingColor(r: number) {
  if (r >= 90) return "#f59e0b";
  if (r >= 80) return "#4ade80";
  if (r >= 70) return "#60a5fa";
  return "#94a3b8";
}

export function PlayerMarker({
  player, jerseyColor, secondaryColor, accentColor, jerseyStyle,
  showDetails, onUpdate, containerRef,
}: PlayerMarkerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [library, setLibrary] = useState<LibPlayer[]>([]);
  const [showLib, setShowLib] = useState(false);
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");

  const handleOpen = (open: boolean) => {
    if (open) setLibrary(loadLibrary());
    setIsOpen(open);
    setShowLib(false);
  };

  const handleDragEnd = (_e: any, info: any) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const newX = Math.max(5, Math.min(95, ((info.point.x - rect.left) / rect.width) * 100));
    const newY = Math.max(5, Math.min(95, ((info.point.y - rect.top) / rect.height) * 100));
    onUpdate(player.id, { x: newX, y: newY });
  };

  const handleSaveToLib = () => {
    const entry: LibPlayer = {
      name: player.name, number: player.number,
      position: player.position, nationality: player.nationality,
      rating: player.rating ?? 80, isCaptain: false,
    };
    const existing = loadLibrary();
    if (existing.some(p => p.name === entry.name)) return;
    const updated = [entry, ...existing];
    saveLibrary(updated);
    setLibrary(updated);
  };

  const handleLoadFromLib = (p: LibPlayer) => {
    onUpdate(player.id, { name: p.name, number: p.number, position: p.position, nationality: p.nationality, rating: p.rating });
    setShowLib(false);
  };

  const handleDeleteFromLib = (idx: number) => {
    const updated = library.filter((_, i) => i !== idx);
    saveLibrary(updated);
    setLibrary(updated);
  };

  const country = countries.find(c => c.code === player.nationality) || countries[0];
  const rating = player.rating ?? 80;

  return (
    <Dialog open={isOpen} onOpenChange={handleOpen}>
      <DialogTrigger asChild>
        <motion.div
          drag
          dragConstraints={containerRef}
          dragElastic={0}
          dragMomentum={false}
          onDragEnd={handleDragEnd}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.97 }}
          className="absolute flex flex-col items-center cursor-grab active:cursor-grabbing group z-10 hover:z-20 transform -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${player.x}%`, top: `${player.y}%` }}
        >
          {/* Jersey */}
          <div
            className="relative w-11 h-11 md:w-12 md:h-12"
            style={{ filter: "drop-shadow(0 4px 10px rgba(0,0,0,0.55))" }}
          >
            <JerseySVG
              uid={player.id}
              color1={jerseyColor}
              color2={secondaryColor}
              color3={accentColor}
              style={jerseyStyle}
              number={player.number}
            />
            {player.isCaptain && (
              <div className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center shadow-lg z-10 border-2 border-black/40">
                <span className="text-[9px] font-black text-black leading-none">C</span>
              </div>
            )}
          </div>

          {/* Name plate row: [flag badge] [plate] */}
          <div className="mt-1.5 flex items-center whitespace-nowrap">
            {/* Round flag badge — sits to the left, overlaps slightly */}
            {showDetails && (
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center overflow-hidden shrink-0 z-10 -mr-1"
                style={{
                  background: "rgba(0,0,0,0.85)",
                  border: `2px solid ${jerseyColor}`,
                  boxShadow: "0 2px 6px rgba(0,0,0,0.5)",
                }}
              >
                {country.isCustom
                  ? <img src={`${base}/istanmusta-flag.png`} alt="flag" className="w-full h-full object-cover" />
                  : <span className="text-[11px] leading-none">{country.flag}</span>
                }
              </div>
            )}

            {/* Name plate */}
            <div
              className="flex items-center gap-1 px-2 py-[3px] rounded"
              style={{
                background: "rgba(0,0,0,0.72)",
                backdropFilter: "blur(8px)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderLeft: showDetails ? "none" : `2px solid ${jerseyColor}`,
                boxShadow: "0 2px 8px rgba(0,0,0,0.5)",
                paddingLeft: showDetails ? "8px" : undefined,
              }}
            >
              <span className="text-white text-[10px] font-bold tracking-wide uppercase leading-none">
                {player.name}
              </span>
              {showDetails && (
                <span className="text-white/40 text-[8px] leading-none ml-0.5">{player.position}</span>
              )}
              <span className="text-[10px] font-black leading-none ml-0.5" style={{ color: ratingColor(rating) }}>
                {rating}
              </span>
            </div>
          </div>
        </motion.div>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[460px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Éditer le joueur</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right text-sm">Nom</Label>
            <Input value={player.name} onChange={e => onUpdate(player.id, { name: e.target.value })} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right text-sm">Numéro</Label>
            <Input value={player.number} onChange={e => onUpdate(player.id, { number: e.target.value })} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right text-sm">Note OVR</Label>
            <div className="col-span-3 flex items-center gap-3">
              <Input type="range" min={1} max={99} value={rating} onChange={e => onUpdate(player.id, { rating: parseInt(e.target.value) })} className="flex-1" />
              <span className="font-black text-xl w-9 text-right tabular-nums" style={{ color: ratingColor(rating) }}>
                {rating}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right text-sm">Position</Label>
            <Input value={player.position} onChange={e => onUpdate(player.id, { position: e.target.value })} className="col-span-3" />
          </div>

          {/* Nationality with search */}
          <div className="space-y-1.5">
            <Label className="text-sm">Nationalité</Label>
            <NationalityPicker
              value={player.nationality}
              onChange={v => onUpdate(player.id, { nationality: v })}
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right text-sm">Capitaine</Label>
            <Switch checked={!!player.isCaptain} onCheckedChange={v => onUpdate(player.id, { isCaptain: v })} />
          </div>

          {/* Library */}
          <div className="border-t border-border pt-3 flex gap-2">
            <Button variant="outline" size="sm" onClick={handleSaveToLib} className="flex-1">
              <Star className="w-3 h-3 mr-1.5" />Sauvegarder
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowLib(v => !v)} className="flex-1">
              <UserPlus className="w-3 h-3 mr-1.5" />{showLib ? "Fermer" : "Choisir un joueur"}
            </Button>
          </div>

          {showLib && (
            <div className="border border-border rounded-lg overflow-hidden">
              {library.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-5">Bibliothèque vide.</p>
              ) : (
                <div className="max-h-52 overflow-y-auto divide-y divide-border">
                  {library.map((p, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-2 hover:bg-muted/40 transition-colors">
                      <div className="flex-1 min-w-0">
                        <span className="text-sm font-semibold">{p.name}</span>
                        <span className="text-xs text-muted-foreground ml-2">#{p.number} · {p.position}</span>
                      </div>
                      <span className="text-xs font-black tabular-nums" style={{ color: ratingColor(p.rating ?? 80) }}>{p.rating ?? 80}</span>
                      <Button variant="ghost" size="sm" onClick={() => handleLoadFromLib(p)} className="text-primary hover:text-primary px-2 h-7 text-xs">Choisir</Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteFromLib(i)} className="text-destructive hover:text-destructive h-7 w-7">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
