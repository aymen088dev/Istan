import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Player } from "@/lib/formations";
import { JerseySVG, type JerseyStyle } from "@/components/JerseySVG";
import { NationalityPicker } from "@/components/NationalityPicker";

type BenchMarkerProps = {
  player: Player;
  jerseyColor: string;
  secondaryColor: string;
  accentColor: string;
  jerseyStyle: JerseyStyle;
  onUpdate: (id: string, updates: Partial<Player>) => void;
};

function ratingColor(r: number) {
  if (r >= 90) return "#f59e0b";
  if (r >= 80) return "#22c55e";
  if (r >= 70) return "#3b82f6";
  return "#94a3b8";
}

export function BenchMarker({ player, jerseyColor, secondaryColor, accentColor, jerseyStyle, onUpdate }: BenchMarkerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const rating = player.rating ?? 75;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <button className="flex flex-col items-center gap-1 cursor-pointer group transition-all hover:scale-105 px-1.5 py-1.5 rounded-lg hover:bg-white/5">
          <div className="relative w-9 h-9" style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.5))" }}>
            <JerseySVG
              uid={player.id}
              color1={jerseyColor}
              color2={secondaryColor}
              color3={accentColor}
              style={jerseyStyle}
              number={player.number}
            />
          </div>
          <div
            className="flex items-center gap-1 px-1.5 py-[2px] rounded-sm"
            style={{
              background: "rgba(0,0,0,0.5)",
              border: `1px solid rgba(255,255,255,0.07)`,
              borderLeft: `1.5px solid ${jerseyColor}`,
            }}
          >
            <span className="text-white/80 text-[8.5px] font-bold uppercase tracking-wide max-w-[44px] truncate leading-none">
              {player.name}
            </span>
            <span className="text-[8px] font-black leading-none" style={{ color: ratingColor(rating) }}>
              {rating}
            </span>
          </div>
        </button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Remplaçant</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Nom</Label>
            <Input value={player.name} onChange={e => onUpdate(player.id, { name: e.target.value })} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Numéro</Label>
            <Input value={player.number} onChange={e => onUpdate(player.id, { number: e.target.value })} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Note OVR</Label>
            <div className="col-span-3 flex items-center gap-3">
              <Input type="range" min={1} max={99} value={rating} onChange={e => onUpdate(player.id, { rating: parseInt(e.target.value) })} className="flex-1" />
              <span className="font-black text-lg w-8 text-right" style={{ color: ratingColor(rating) }}>{rating}</span>
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label className="text-right">Position</Label>
            <Input value={player.position} onChange={e => onUpdate(player.id, { position: e.target.value })} className="col-span-3" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-sm">Nationalité</Label>
            <NationalityPicker
              value={player.nationality}
              onChange={v => onUpdate(player.id, { nationality: v })}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
