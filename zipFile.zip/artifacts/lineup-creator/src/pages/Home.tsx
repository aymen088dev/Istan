import { useState, useRef, useEffect, useCallback } from "react";
import html2canvas from "html2canvas-pro";
import { Download, Upload, Image as ImageIcon, Settings, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { FOOTBALL_FORMATIONS, HOCKEY_FORMATIONS, Player } from "@/lib/formations";
import { PlayerMarker } from "@/components/PlayerMarker";
import { BenchMarker } from "@/components/BenchMarker";
import { CompositionLibrary, type SavedComposition } from "@/components/CompositionLibrary";
import { JerseySVG, type JerseyStyle, JERSEY_STYLE_LABELS } from "@/components/JerseySVG";
import { BACKGROUNDS, getBackgroundsForSport, getDefaultBackground } from "@/lib/backgrounds";

const COLOR_PRESETS = [
  { label: "Vert",        jersey: "#10b981", text: "#ffffff", accent: "#064e3b" },
  { label: "Bleu Royal",  jersey: "#1d4ed8", text: "#ffffff", accent: "#1e3a8a" },
  { label: "Rouge Vif",   jersey: "#dc2626", text: "#ffffff", accent: "#7f1d1d" },
  { label: "Noir/Or",     jersey: "#111827", text: "#f59e0b", accent: "#ffffff" },
  { label: "Blanc/Noir",  jersey: "#f9fafb", text: "#111827", accent: "#374151" },
  { label: "Bordeaux",    jersey: "#7c0a02", text: "#ffffff", accent: "#ffd700" },
  { label: "Orange",      jersey: "#ea580c", text: "#ffffff", accent: "#1c1917" },
  { label: "Violet",      jersey: "#7c3aed", text: "#ffffff", accent: "#ede9fe" },
  { label: "PSG",         jersey: "#001a4e", text: "#dc143c", accent: "#d4af37" },
  { label: "OM",          jersey: "#009fda", text: "#ffffff", accent: "#003d5b" },
  { label: "Barça",       jersey: "#004d98", text: "#a50044", accent: "#ffed00" },
  { label: "Real Madrid", jersey: "#f9fafb", text: "#001a4e", accent: "#d4af37" },
];

const JERSEY_STYLES: JerseyStyle[] = ["plain", "bicolor", "striped", "hoops", "sash"];

const STORAGE_KEY = "lineup-creator-state-v2";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function buildBench(sport: "football" | "hockey"): Player[] {
  const count = sport === "football" ? 7 : 4;
  return Array.from({ length: count }, (_, i) => ({
    id: `bench-${i}`,
    name: `Rmp ${i + 1}`,
    number: `${i + 12}`,
    position: "RMP",
    nationality: "FR",
    rating: 75,
    isCaptain: false,
    x: 0,
    y: 0,
  }));
}

function mapY(y: number) {
  const fromMin = 12, fromMax = 88, toMin = 23, toMax = 85;
  return toMin + ((y - fromMin) / (fromMax - fromMin)) * (toMax - toMin);
}
function mapX(x: number) {
  return Math.max(8, Math.min(92, x));
}

export default function Home() {
  const saved = loadState();

  const [sport, setSport] = useState<"football" | "hockey">(saved?.sport ?? "football");
  const [formation, setFormation] = useState<string>(saved?.formation ?? "4-3-3");
  const [players, setPlayers] = useState<Player[]>(saved?.players ?? []);
  const [bench, setBench] = useState<Player[]>(saved?.bench ?? []);
  const [title, setTitle] = useState<string>(saved?.title ?? "XI DE DÉPART");
  const [jerseyColor, setJerseyColor] = useState<string>(saved?.jerseyColor ?? "#10b981");
  const [secondaryColor, setSecondaryColor] = useState<string>(saved?.secondaryColor ?? "#ffffff");
  const [accentColor, setAccentColor] = useState<string>(saved?.accentColor ?? "#064e3b");
  const [jerseyStyle, setJerseyStyle] = useState<JerseyStyle>(saved?.jerseyStyle ?? "plain");
  const [backgroundId, setBackgroundId] = useState<string>(saved?.backgroundId ?? "football-standard");
  const [showDetails, setShowDetails] = useState<boolean>(saved?.showDetails ?? false);
  const [showBench, setShowBench] = useState<boolean>(saved?.showBench ?? true);
  const [bgImage, setBgImage] = useState<string | null>(null);
  const [logoImage, setLogoImage] = useState<string | null>(null);

  const compositionRef = useRef<HTMLDivElement>(null);
  const pitchRef = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  const initPlayers = useCallback((s: "football" | "hockey", f: string) => {
    const formations = s === "football" ? FOOTBALL_FORMATIONS : HOCKEY_FORMATIONS;
    const key = formations[f] ? f : (s === "football" ? "4-3-3" : "1-2-2 (Standard)");
    return formations[key].positions.map((pos, i) => ({
      id: `player-${i}`,
      name: `Joueur ${i + 1}`,
      number: `${i + 1}`,
      position: pos.label,
      nationality: "FR",
      rating: 80,
      isCaptain: false,
      x: mapX(pos.x),
      y: mapY(pos.y),
    }));
  }, []);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    if (!saved?.players?.length) {
      setPlayers(initPlayers(sport, formation));
      setBench(buildBench(sport));
    }
  }, []);

  useEffect(() => {
    if (!initialized.current) return;
    const formations = sport === "football" ? FOOTBALL_FORMATIONS : HOCKEY_FORMATIONS;
    if (!formations[formation]) {
      const key = sport === "football" ? "4-3-3" : "1-2-2 (Standard)";
      setFormation(key);
      setPlayers(initPlayers(sport, key));
    } else {
      setPlayers(initPlayers(sport, formation));
    }
    setBench(buildBench(sport));
    setBackgroundId(getDefaultBackground(sport));
  }, [sport, formation]);

  useEffect(() => {
    const state = { sport, formation, players, bench, title, jerseyColor, secondaryColor, accentColor, jerseyStyle, backgroundId, showDetails, showBench };
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
  }, [sport, formation, players, bench, title, jerseyColor, secondaryColor, accentColor, jerseyStyle, backgroundId, showDetails, showBench]);

  const updatePlayer = (id: string, updates: Partial<Player>) =>
    setPlayers(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));

  const updateBenchPlayer = (id: string, updates: Partial<Player>) =>
    setBench(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));

  const handleReset = () => {
    setPlayers(initPlayers(sport, formation));
    setBench(buildBench(sport));
  };

  const handleLoadComposition = (c: SavedComposition) => {
    setSport(c.sport);
    setFormation(c.formation);
    setTitle(c.title);
    setPlayers(c.players);
    setBench(c.bench);
    setJerseyColor(c.jerseyColor);
    setSecondaryColor(c.secondaryColor);
    setAccentColor(c.accentColor ?? "#064e3b");
    setJerseyStyle((c.jerseyStyle as JerseyStyle) ?? "plain");
    setBackgroundId(c.backgroundId ?? getDefaultBackground(c.sport));
    setShowBench(c.showBench ?? true);
    setShowDetails(c.showDetails ?? false);
  };

  const handleExport = async () => {
    if (!compositionRef.current) return;
    try {
      const el = compositionRef.current;
      const canvas = await html2canvas(el, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#111827",
        logging: false,
        x: 0,
        y: 0,
        scrollX: 0,
        scrollY: 0,
        width: el.offsetWidth,
        height: el.offsetHeight,
      });
      const url = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = url;
      a.download = `composition-${sport}-${Date.now()}.png`;
      a.click();
    } catch (err) {
      console.error("Export failed", err);
    }
  };

  const activeBg = BACKGROUNDS.find(b => b.id === backgroundId);
  const bgClass = activeBg?.cssClass ?? (sport === "football" ? "pitch-bg" : "rink-bg");

  const currentState = {
    sport, formation, title, players, bench,
    jerseyColor, secondaryColor, accentColor, jerseyStyle: jerseyStyle as string,
    backgroundId, showBench, showDetails,
  };

  return (
    <div className="min-h-screen w-full flex flex-col md:flex-row bg-background">
      {/* Left: Composition */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 overflow-hidden relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] max-w-[800px] max-h-[800px] bg-primary/10 blur-[100px] rounded-full pointer-events-none" />

        <div
          className="w-full max-w-[480px] relative rounded-xl overflow-hidden border border-white/10"
          style={{ boxShadow: "0 25px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05)" }}
          ref={compositionRef}
        >
          {/* Pitch */}
          <div className="relative w-full" style={{ aspectRatio: "3/4" }}>
            {/* Background */}
            <div
              className={`absolute inset-0 w-full h-full ${bgImage ? "" : bgClass}`}
              style={bgImage ? { backgroundImage: `url(${bgImage})`, backgroundSize: "cover", backgroundPosition: "center" } : {}}
              ref={pitchRef}
            />

            {/* Overlay: dark band top + bottom, transparent middle so players pop */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.15) 22%, rgba(0,0,0,0) 40%, rgba(0,0,0,0) 72%, rgba(0,0,0,0.65) 100%)" }}
            />

            {/* Title block */}
            <div className="absolute top-0 left-0 right-0 pt-4 pb-3 flex flex-col items-center z-[1] pointer-events-none">
              <h1
                className="text-white font-black uppercase text-center whitespace-nowrap overflow-hidden w-full"
                style={{
                  fontSize: "clamp(13px, 5.8vw, 26px)",
                  letterSpacing: "0.14em",
                  textShadow: "0 2px 16px rgba(0,0,0,0.9), 0 0 40px rgba(0,0,0,0.6)",
                  paddingLeft: "12px",
                  paddingRight: logoImage ? "76px" : "12px",
                }}
              >
                {title}
              </h1>
              {/* Accent line */}
              <div className="mt-2 h-[2px] w-16 rounded-full opacity-70" style={{ background: jerseyColor }} />
            </div>

            {/* Logo */}
            {logoImage && (
              <div className="absolute top-3 right-3 z-10 pointer-events-none">
                <img src={logoImage} alt="Logo" className="w-14 h-14 object-contain drop-shadow-lg" />
              </div>
            )}

            {/* Players */}
            {players.map(p => (
              <PlayerMarker
                key={p.id}
                player={p}
                jerseyColor={jerseyColor}
                secondaryColor={secondaryColor}
                accentColor={accentColor}
                jerseyStyle={jerseyStyle}
                showDetails={showDetails}
                onUpdate={updatePlayer}
                containerRef={pitchRef}
              />
            ))}

            {/* Watermark */}
            <div className="absolute bottom-3 left-0 right-0 text-center pointer-events-none">
              <span
                className="text-white/30 font-semibold uppercase"
                style={{ fontSize: "9px", letterSpacing: "0.22em" }}
              >
                ★ XI DESCORE90 ★
              </span>
            </div>
          </div>

          {/* Bench */}
          {showBench && (
            <div
              className="border-t border-white/[0.06] px-4 py-4"
              style={{ background: "linear-gradient(135deg, #080c14 0%, #0e1520 100%)" }}
            >
              {/* Accent top bar */}
              <div className="flex items-center justify-center gap-3 mb-3">
                <div className="flex-1 h-px bg-white/8" />
                <span className="text-white/30 font-bold uppercase" style={{ fontSize: "9px", letterSpacing: "0.22em" }}>
                  Remplaçants
                </span>
                <div className="flex-1 h-px bg-white/8" />
              </div>
              <div className="flex items-start justify-center gap-2 flex-wrap">
                {bench.map(p => (
                  <BenchMarker
                    key={p.id}
                    player={p}
                    jerseyColor={jerseyColor}
                    secondaryColor={secondaryColor}
                    accentColor={accentColor}
                    jerseyStyle={jerseyStyle}
                    onUpdate={updateBenchPlayer}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: Sidebar */}
      <div className="w-full md:w-[380px] bg-card border-t md:border-t-0 md:border-l border-border p-6 flex flex-col overflow-y-auto z-10 shrink-0 shadow-2xl relative">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            Paramètres
          </h2>
          <div className="flex gap-2">
            <CompositionLibrary currentState={currentState} onLoad={handleLoadComposition} />
            <Button variant="outline" size="icon" onClick={handleReset} title="Réinitialiser">
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button onClick={handleExport} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold shadow-[0_0_15px_rgba(16,185,129,0.3)]">
              <Download className="w-4 h-4 mr-2" />
              Exporter
            </Button>
          </div>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="general">Général</TabsTrigger>
            <TabsTrigger value="kit">Kit</TabsTrigger>
            <TabsTrigger value="style">Style</TabsTrigger>
          </TabsList>

          {/* ── GÉNÉRAL ── */}
          <TabsContent value="general" className="space-y-6">
            <div className="space-y-3">
              <Label>Sport</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button variant={sport === "football" ? "default" : "outline"} onClick={() => setSport("football")}>⚽ Football</Button>
                <Button variant={sport === "hockey" ? "default" : "outline"} onClick={() => setSport("hockey")}>🏒 Hockey</Button>
              </div>
            </div>

            <div className="space-y-3">
              <Label>Formation</Label>
              <Select value={formation} onValueChange={f => { setFormation(f); setPlayers(initPlayers(sport, f)); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72 overflow-y-auto">
                  {Object.keys(sport === "football" ? FOOTBALL_FORMATIONS : HOCKEY_FORMATIONS).map(f => (
                    <SelectItem key={f} value={f}>{f}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label>Titre</Label>
              <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="XI DE DÉPART" />
            </div>

            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border border-border">
              <div>
                <Label className="text-sm">Détails avancés</Label>
                <p className="text-xs text-muted-foreground">Afficher nationalité et position</p>
              </div>
              <Switch checked={showDetails} onCheckedChange={setShowDetails} />
            </div>

            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border border-border">
              <div>
                <Label className="text-sm">Remplaçants</Label>
                <p className="text-xs text-muted-foreground">Afficher le banc dans l'export</p>
              </div>
              <Switch checked={showBench} onCheckedChange={setShowBench} />
            </div>
          </TabsContent>

          {/* ── KIT ── */}
          <TabsContent value="kit" className="space-y-6">
            <div className="space-y-3">
              <Label>Style de maillot</Label>
              <div className="grid grid-cols-5 gap-2">
                {JERSEY_STYLES.map(s => (
                  <button
                    key={s}
                    onClick={() => setJerseyStyle(s)}
                    title={JERSEY_STYLE_LABELS[s]}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg border-2 transition-all hover:bg-muted/40 ${jerseyStyle === s ? "border-primary bg-primary/10" : "border-border"}`}
                  >
                    <div className="w-10 h-10">
                      <JerseySVG uid={`preview-${s}`} color1={jerseyColor} color2={secondaryColor} color3={accentColor} style={s} number="" />
                    </div>
                    <span className="text-[10px] text-muted-foreground leading-tight text-center">{JERSEY_STYLE_LABELS[s]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Presets d'équipe</Label>
              <div className="grid grid-cols-6 gap-2">
                {COLOR_PRESETS.map(preset => (
                  <button
                    key={preset.label}
                    title={preset.label}
                    onClick={() => { setJerseyColor(preset.jersey); setSecondaryColor(preset.text); setAccentColor(preset.accent); }}
                    className="w-9 h-9 rounded-full border-2 transition-all hover:scale-110"
                    style={{
                      background: `linear-gradient(135deg, ${preset.jersey} 50%, ${preset.text} 50%)`,
                      borderColor: jerseyColor === preset.jersey ? "white" : "transparent",
                    }}
                  />
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-xs">Couleur 1</Label>
                <div className="flex flex-col gap-1">
                  <Input type="color" value={jerseyColor} onChange={e => setJerseyColor(e.target.value)} className="w-full h-10 p-1 cursor-pointer bg-transparent" />
                  <Input type="text" value={jerseyColor} onChange={e => setJerseyColor(e.target.value)} className="font-mono text-xs" />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Couleur 2</Label>
                <div className="flex flex-col gap-1">
                  <Input type="color" value={secondaryColor} onChange={e => setSecondaryColor(e.target.value)} className="w-full h-10 p-1 cursor-pointer bg-transparent" />
                  <Input type="text" value={secondaryColor} onChange={e => setSecondaryColor(e.target.value)} className="font-mono text-xs" />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Couleur 3</Label>
                <div className="flex flex-col gap-1">
                  <Input type="color" value={accentColor} onChange={e => setAccentColor(e.target.value)} className="w-full h-10 p-1 cursor-pointer bg-transparent" />
                  <Input type="text" value={accentColor} onChange={e => setAccentColor(e.target.value)} className="font-mono text-xs" />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ── STYLE ── */}
          <TabsContent value="style" className="space-y-6">
            {/* Background picker */}
            <div className="space-y-3">
              <Label>Style de terrain</Label>
              <div className="grid grid-cols-3 gap-2">
                {getBackgroundsForSport(sport).map(bg => (
                  <button
                    key={bg.id}
                    onClick={() => { setBackgroundId(bg.id); setBgImage(null); }}
                    className={`h-14 rounded-lg border-2 transition-all overflow-hidden relative hover:scale-[1.02] ${backgroundId === bg.id ? "border-primary ring-2 ring-primary/30" : "border-border"}`}
                  >
                    <div className={`w-full h-full ${bg.cssClass}`} />
                    <div className="absolute inset-0 bg-black/40 flex items-end justify-center pb-1">
                      <span className="text-white text-[9px] font-semibold uppercase tracking-wide">{bg.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <Card className="bg-transparent border-border/50">
              <CardContent className="p-4 space-y-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Logo Équipe</Label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" className="w-full relative overflow-hidden">
                      <Upload className="w-4 h-4 mr-2" />Choisir une image
                      <input type="file" accept="image/*" onChange={e => e.target.files?.[0] && setLogoImage(URL.createObjectURL(e.target.files[0]))} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </Button>
                    {logoImage && (
                      <Button variant="ghost" size="icon" onClick={() => setLogoImage(null)} className="shrink-0 text-destructive hover:text-destructive hover:bg-destructive/10">&times;</Button>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Fond personnalisé</Label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" className="w-full relative overflow-hidden">
                      <Upload className="w-4 h-4 mr-2" />Choisir une image
                      <input type="file" accept="image/*" onChange={e => e.target.files?.[0] && setBgImage(URL.createObjectURL(e.target.files[0]))} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </Button>
                    {bgImage && (
                      <Button variant="ghost" size="icon" onClick={() => setBgImage(null)} className="shrink-0 text-destructive hover:text-destructive hover:bg-destructive/10">&times;</Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
