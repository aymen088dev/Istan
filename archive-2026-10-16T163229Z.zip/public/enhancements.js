(() => {
    "use strict";

    const PROFILE_KEY = "publisher.lastProfile";
    const CATEGORY_KEY = "publisher.lastCategory";
    const WEBHOOK_KEY = "publisher.lastWebhook";
    const DRAFT_KEY = "publisher.messageDraft";
    let libraryProfiles = [];
    let libraryCategories = [];
    let activeCategory = "all";

    const byId = id => document.getElementById(id);
    const safeText = value => String(value || "").toLocaleLowerCase("fr");
    const escapeHtml = value => {
        const element = document.createElement("span");
        element.textContent = value ?? "";
        return element.innerHTML;
    };

    function init() {
        installFeedback();
        bindShortcuts();
        bindComposer();
        bindNavigation();
        observeDynamicModals();
        loadLibrary();
        loadMessageMetric();
        restoreDraft();
        syncComposerChannel();
        observeFeed();
    }

    function installFeedback() {
        const region = byId("toastRegion");
        if (!region) return;
        window.publisherToast = (message, tone = "default") => {
            const toast = document.createElement("div");
            toast.className = `toast toast-${tone}`;
            toast.setAttribute("role", "status");
            toast.innerHTML = `<span class="toast-mark" aria-hidden="true"></span><span>${escapeHtml(message)}</span>`;
            region.appendChild(toast);
            window.setTimeout(() => {
                toast.classList.add("is-leaving");
                window.setTimeout(() => toast.remove(), 220);
            }, 3400);
        };
        const nativeAlert = window.alert.bind(window);
        window.alert = message => {
            if (window.publisherToast) window.publisherToast(message, "error");
            else nativeAlert(message);
        };
        byId("publishButton")?.addEventListener("click", () => {
            const button = byId("publishButton");
            if (button && !button.disabled) {
                button.classList.add("is-pressing");
                window.setTimeout(() => button.classList.remove("is-pressing"), 420);
            }
        });
    }

    function bindNavigation() {
        const goToComposer = () => {
            const composer = byId("messageInput");
            composer?.scrollIntoView({ behavior: "smooth", block: "center" });
            window.setTimeout(() => composer?.focus(), 350);
        };
        byId("heroPublishButton")?.addEventListener("click", goToComposer);
        ["openDirectoryButton", "sideDirectoryButton", "viewAllProfilesButton"].forEach(id => {
            byId(id)?.addEventListener("click", () => window.openProfileSelector?.());
        });
        byId("focusSearchButton")?.addEventListener("click", () => {
            const input = byId("profileQuickSearch");
            input?.focus();
            input?.scrollIntoView({ behavior: "smooth", block: "center" });
        });
    }

    function bindShortcuts() {
        document.addEventListener("keydown", event => {
            if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName)) {
                event.preventDefault();
                byId("profileQuickSearch")?.focus();
            }
            if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
                event.preventDefault();
                byId("publishButton")?.click();
            }
        });
    }

    function bindComposer() {
        const input = byId("messageInput");
        if (!input) return;
        const status = byId("draftStatus");
        const length = byId("messageLength");
        const update = () => {
            if (length) length.textContent = input.value.length;
            window.clearTimeout(input._draftTimer);
            input._draftTimer = window.setTimeout(() => {
                localStorage.setItem(DRAFT_KEY, input.value);
                if (status) {
                    status.textContent = input.value ? "Brouillon sauvegardé" : "Nouveau brouillon";
                }
            }, 280);
        };
        input.addEventListener("input", update);
        byId("clearDraftButton")?.addEventListener("click", () => {
            input.value = "";
            localStorage.removeItem(DRAFT_KEY);
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.focus();
            window.publisherToast?.("Brouillon effacé");
        });
        update();
    }

    function restoreDraft() {
        const input = byId("messageInput");
        if (!input) return;
        const draft = localStorage.getItem(DRAFT_KEY);
        if (draft && !input.value) {
            input.value = draft;
            input.dispatchEvent(new Event("input", { bubbles: true }));
        }
    }

    async function loadLibrary() {
        try {
            const [profilesResponse, categoriesResponse] = await Promise.all([
                fetch("/api/profiles", { cache: "no-store" }),
                fetch("/api/categories", { cache: "no-store" })
            ]);
            if (!profilesResponse.ok || !categoriesResponse.ok) throw new Error("Bibliothèque indisponible");
            libraryProfiles = await profilesResponse.json();
            libraryCategories = await categoriesResponse.json();
            byId("profileCount").textContent = libraryProfiles.length;
            byId("categoryCount").textContent = libraryCategories.length;
            renderCategoryFilters();
            renderQuickProfiles();
        } catch (error) {
            console.warn("Bibliothèque non disponible", error);
            byId("profileCount").textContent = "—";
            byId("categoryCount").textContent = "—";
            const list = byId("recentProfiles");
            if (list) list.innerHTML = '<div class="panel-empty">Impossible de charger les profils.</div>';
        }
    }

    async function loadMessageMetric() {
        try {
            const response = await fetch("/api/discord/messages?limit=100", { cache: "no-store" });
            if (!response.ok) throw new Error("Messages indisponibles");
            const messages = await response.json();
            byId("messageCount").textContent = Array.isArray(messages) ? messages.length : "—";
            updateFeedSummary(Array.isArray(messages) ? messages.length : 0);
        } catch {
            byId("messageCount").textContent = "—";
        }
    }

    function renderCategoryFilters() {
        const row = byId("quickCategoryFilters");
        if (!row) return;
        row.innerHTML = '<button class="filter-chip is-active" type="button" data-category="all">Tous</button>';
        libraryCategories.forEach(category => {
            const button = document.createElement("button");
            button.className = "filter-chip";
            button.type = "button";
            button.dataset.category = category.name;
            button.textContent = category.name;
            row.appendChild(button);
        });
        row.addEventListener("click", event => {
            const button = event.target.closest(".filter-chip");
            if (!button) return;
            activeCategory = button.dataset.category || "all";
            row.querySelectorAll(".filter-chip").forEach(item => item.classList.toggle("is-active", item === button));
            renderQuickProfiles();
        });
    }

    function renderQuickProfiles() {
        const list = byId("recentProfiles");
        if (!list) return;
        const query = safeText(byId("profileQuickSearch")?.value);
        const filtered = libraryProfiles.filter(profile => {
            const matchesCategory = activeCategory === "all" || profile.category === activeCategory;
            const haystack = safeText(`${profile.name} ${profile.category || ""}`);
            return matchesCategory && haystack.includes(query);
        });
        if (!filtered.length) {
            list.innerHTML = '<div class="panel-empty">Aucun profil ne correspond.</div>';
            return;
        }
        list.innerHTML = filtered.slice(0, 7).map(profile => {
            const avatar = profile.avatar
                ? `<img src="${escapeHtml(profile.avatar)}?v=${encodeURIComponent(profile.updatedAt || profile.createdAt || "")}" alt="">`
                : `<span>${escapeHtml(profile.name?.charAt(0)?.toUpperCase() || "?")}</span>`;
            return `<button type="button" class="quick-profile" data-profile="${escapeHtml(profile.folder)}">
                <span class="quick-profile-avatar">${avatar}</span>
                <span class="quick-profile-copy">
                    <span class="quick-profile-name">${escapeHtml(profile.name)}${profile.verified ? ' <span class="verified-badge">✓</span>' : ""}</span>
                    <span class="quick-profile-category">${escapeHtml(profile.category || "Sans catégorie")}</span>
                </span>
                <span class="quick-profile-arrow">↗</span>
            </button>`;
        }).join("");
        list.querySelectorAll(".quick-profile").forEach(button => {
            button.addEventListener("click", () => chooseProfileFromLibrary(button.dataset.profile));
        });
    }

    async function chooseProfileFromLibrary(folder) {
        localStorage.setItem(PROFILE_KEY, folder);
        window.openProfileSelector?.();
        await waitFor(() => document.querySelector(".profile-modal"));
        const modal = document.querySelector(".profile-modal");
        const cards = [...(modal?.querySelectorAll(".profile-card") || [])];
        const profile = libraryProfiles.find(item => item.folder === folder);
        const card = cards.find(item => safeText(item.textContent).includes(safeText(profile?.name)));
        card?.querySelector(".profile-select-button")?.click();
    }

    function observeDynamicModals() {
        const observer = new MutationObserver(mutations => {
            mutations.flatMap(mutation => [...mutation.addedNodes]).forEach(node => {
                if (!(node instanceof HTMLElement)) return;
                if (node.matches(".modal")) enhanceModal(node);
                node.querySelectorAll?.(".modal").forEach(enhanceModal);
            });
        });
        observer.observe(document.body, { childList: true });
        document.addEventListener("click", event => {
            const tab = event.target.closest(".category-tab");
            if (tab && tab.dataset.category) {
                activeCategory = tab.dataset.category;
                if (tab.dataset.category !== "all") localStorage.setItem(CATEGORY_KEY, tab.dataset.category);
            }
            const selected = event.target.closest(".profile-select-button");
            if (selected) {
                const card = selected.closest(".profile-card");
                const name = card?.querySelector(".profile-card-name")?.textContent?.replace("✓", "").trim();
                const profile = libraryProfiles.find(item => item.name === name);
                if (profile) localStorage.setItem(PROFILE_KEY, profile.folder);
            }
            const webhook = event.target.closest(".webhook-option");
            if (webhook?.dataset.folder) localStorage.setItem(WEBHOOK_KEY, webhook.dataset.folder);
        });
        const category = localStorage.getItem(CATEGORY_KEY);
        if (category) activeCategory = category;
    }

    function enhanceModal(modal) {
        if (!modal.querySelector(".profile-modal")) return;
        const toolbar = modal.querySelector(".profile-modal-toolbar");
        if (!toolbar || toolbar.querySelector(".profile-search-row")) return;
        const row = document.createElement("label");
        row.className = "profile-search-row search-field";
        row.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.7"></circle><path d="m16 16 5 5"></path></svg><input class="profile-search-input" type="search" placeholder="Filtrer les profils..." autocomplete="off">';
        toolbar.prepend(row);
        const input = row.querySelector("input");
        input.addEventListener("input", () => filterModalProfiles(modal, input.value));
        const remembered = localStorage.getItem(CATEGORY_KEY);
        if (remembered) {
            window.setTimeout(() => modal.querySelector(`.category-tab[data-category="${CSS.escape(remembered)}"]`)?.click(), 20);
        }
    }

    function filterModalProfiles(modal, query) {
        const term = safeText(query);
        modal.querySelectorAll(".profile-card").forEach(card => {
            card.hidden = term && !safeText(card.textContent).includes(term);
        });
    }

    function syncComposerChannel() {
        const source = byId("webhookName");
        const destination = byId("composerChannel");
        if (!source || !destination) return;
        const update = () => { destination.textContent = source.textContent === "Aucun webhook" ? "salon sélectionné" : source.textContent; };
        update();
        new MutationObserver(update).observe(source, { childList: true, characterData: true, subtree: true });
    }

    function observeFeed() {
        const feed = byId("discordMessages");
        if (!feed) return;
        new MutationObserver(() => {
            const count = feed.querySelectorAll(".discord-message").length;
            byId("messageCount").textContent = count;
            updateFeedSummary(count);
        }).observe(feed, { childList: true });
    }

    function updateFeedSummary(count) {
        const summary = byId("messageFeedSummary");
        if (summary) summary.textContent = `${count} message${count === 1 ? "" : "s"} récent${count === 1 ? "" : "s"}`;
    }

    function waitFor(predicate, timeout = 1200) {
        return new Promise(resolve => {
            const started = Date.now();
            const check = () => {
                if (predicate()) return resolve(true);
                if (Date.now() - started > timeout) return resolve(false);
                window.setTimeout(check, 30);
            };
            check();
        });
    }

    document.addEventListener("DOMContentLoaded", init);
})();