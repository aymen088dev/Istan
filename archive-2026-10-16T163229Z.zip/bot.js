const {

    Client,

    GatewayIntentBits

} = require("discord.js");

const fs = require("fs");

const path = require("path");

// ==========================================

// CONFIGURATION

// ==========================================

const SERVER_URL =

    "http://localhost:10015";

const BOT_SECRET =

    "CHANGE_MOI_PAR_UN_SECRET";

// Salon Discord à surveiller

const TARGET_CHANNEL_ID =

    "1407091475082383420";

// ==========================================

// TOKEN

// ==========================================

const tokenPath =

    path.join(

        __dirname,

        "token.json"

    );

if (!fs.existsSync(tokenPath)) {

    console.error(

        "❌ Fichier token.json introuvable."

    );

    process.exit(1);

}

let tokenData;

try {

    tokenData =

        JSON.parse(

            fs.readFileSync(

                tokenPath,

                "utf8"

            )

        );

} catch (error) {

    console.error(

        "❌ Impossible de lire token.json."

    );

    process.exit(1);

}

const TOKEN =

    tokenData.token;

if (!TOKEN) {

    console.error(

        "❌ Aucun token trouvé dans token.json."

    );

    process.exit(1);

}

// ==========================================

// CLIENT DISCORD

// ==========================================

const client =

    new Client({

        intents: [

            GatewayIntentBits.Guilds,

            GatewayIntentBits.GuildMessages,

            GatewayIntentBits.MessageContent

        ]

    });

// ==========================================

// BOT PRÊT

// ==========================================

client.once(

    "ready",

    () => {

        console.log(

            "=================================="

        );

        console.log(

            `✅ Bot connecté : ${client.user.tag}`

        );

        console.log(

            `🎯 Salon surveillé : ${TARGET_CHANNEL_ID}`

        );

        console.log(

            `🌐 Serveur : ${SERVER_URL}`

        );

        console.log(

            "=================================="

        );

    }

);

// ==========================================

// NOUVEAU MESSAGE

// ==========================================

client.on(

    "messageCreate",

    async (message) => {

        try {

            // ==================================

            // UNIQUEMENT LE SALON CONCERNÉ

            // ==================================

            if (

                message.channelId !==

                TARGET_CHANNEL_ID

            ) {

                return;

            }

            // ==================================

            // IGNORER LES BOTS

            // ==================================

            if (

                message.author.bot

            ) {

                return;

            }

            // ==================================

            // PIÈCES JOINTES

            // ==================================

            const attachments =

                Array.from(

                    message.attachments.values()

                ).map(

                    attachment => ({

                        id:

                            attachment.id,

                        name:

                            attachment.name,

                        url:

                            attachment.url,

                        proxyUrl:

                            attachment.proxyURL,

                        contentType:

                            attachment.contentType ||

                            null,

                        size:

                            attachment.size

                    })

                );

            // ==================================

            // INFORMATIONS DU MESSAGE

            // ==================================

            const data = {

                id:

                    message.id,

                channelId:

                    message.channelId,

                channelName:

                    message.channel?.name ||

                    null,

                guildId:

                    message.guildId ||

                    null,

                guildName:

                    message.guild?.name ||

                    null,

                authorId:

                    message.author.id,

                authorName:

                    message.author.username,

                authorDisplayName:

                    message.member?.displayName ||

                    message.author.globalName ||

                    message.author.username,

                authorAvatar:

                    message.author.displayAvatarURL({

                        extension:

                            "png",

                        size:

                            128

                    }),

                content:

                    message.content ||

                    "",

                attachments,

                timestamp:

                    message.createdAt.toISOString()

            };

            // ==================================

            // ENVOI À SERVER.JS

            // ==================================

            const response =

                await fetch(

                    `${SERVER_URL}/api/discord/messages`,

                    {

                        method:

                            "POST",

                        headers: {

                            "Content-Type":

                                "application/json",

                            "x-bot-secret":

                                BOT_SECRET

                        },

                        body:

                            JSON.stringify(

                                data

                            )

                    }

                );

            // ==================================

            // ERREUR

            // ==================================

            if (

                !response.ok

            ) {

                const errorText =

                    await response.text();

                console.error(

                    "❌ Server.js a refusé le message :",

                    response.status,

                    errorText

                );

                return;

            }

            // ==================================

            // SUCCÈS

            // ==================================

            console.log(

                `📩 ${message.author.username} → message récupéré`

            );

        } catch (error) {

            console.error(

                "❌ Erreur récupération message :",

                error

            );

        }

    }

);

// ==========================================

// ERREURS DISCORD

// ==========================================

client.on(

    "error",

    (error) => {

        console.error(

            "❌ Erreur Discord :",

            error

        );

    }

);

// ==========================================

// CONNEXION

// ==========================================

client.login(

    TOKEN

);